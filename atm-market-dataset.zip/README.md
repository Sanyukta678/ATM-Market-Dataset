# ATM Market Dataset

This repository contains a compact dataset and supporting files extracted and summarized from the Next Move Strategy Consulting report: *ATM Market — Global Analysis & Forecast, 2025–2030* (report page: https://www.nextmsc.com/report/atm-market-bf3632).

## About
The dataset provides key market figures and curated insights from the source report. It is intended for research, analysis, and educational usage.

## Files Included
- `README.md`
- `summary.txt`
- `atm_summary.csv`
- `metadata.json`
- `LICENSE`

## Citation
Next Move Strategy Consulting — *ATM Market: Global Analysis & Forecast, 2025–2030*. https://www.nextmsc.com/report/atm-market-bf3632
